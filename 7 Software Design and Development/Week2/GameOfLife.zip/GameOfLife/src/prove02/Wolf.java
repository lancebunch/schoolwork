package prove02;

import java.awt.*;
import java.util.Random;

public class Wolf extends Creature implements Aggressor, Aware, Movable, Spawner {
    Random _rand = new Random();
    Direction preferredDirection;
    boolean fertile = false;

    // Inherited functions that need to be set from the Creature class
    public Shape getShape() { return Shape.Square; }

    public Color getColor() { return new Color(150, 150, 150); }

    public Boolean isAlive() { return _health > 0; }

    // Wolf starts with a health of 10, start with a random direction
    public Wolf() {
        _health = 10;
        switch(_rand.nextInt(4)) {
            case 0:
                // _location.x++
                preferredDirection = Direction.right;
                break;
            case 1:
                // _location.x--
                preferredDirection = Direction.left;
                break;
            case 2:
                // _location.y--
                preferredDirection = Direction.above;
                break;
            case 3:
                //_location.y++;
                preferredDirection = Direction.below;
                break;
            default:
                break;
        }
    }

    // Implementing Aggressor function.
    public void attack(Creature target) {
        if (target instanceof Animal) {
            target.takeDamage(5);
            if (!target.isAlive()) {
                fertile = true;
            }
        }
    }

    // Implementing Aware function.
    public void senseNeighbors(Creature above, Creature below, Creature left, Creature right) {
        if (above instanceof Animal) {
            preferredDirection = Direction.above;
        }
        if (right instanceof Animal) {
            preferredDirection = Direction.right;
        }
        if (below instanceof Animal) {
            preferredDirection = Direction.below;
        }
        if (left instanceof Animal) {
            preferredDirection = Direction.left;
        }
    }

    // Implementing Movable function.
    public void move() {
        switch(preferredDirection) {
            case right:
                _location.x++;
                break;
            case left:
                _location.x--;
                break;
            case above:
                _location.y--;
                break;
            case below:
                _location.y++;
                break;
            default:
                break;
        }
    }

    // Implementing Spawner Function
    public Creature spawnNewCreature() {
        if (fertile) {
            Wolf w = new Wolf();
            w.setLocation(new Point(this.getLocation()));
            w._location.x--;
            fertile = false;
            return w;
        }
        else return null;
    }
}
