package bunch;

public class WeatherWind {
    private float speed;

    @Override
    public String toString() {
        return "Wind speed: " + speed + "MPH ";
    }
}
