/***********************************************************************
* Component:
*    Scheduler SJF
* Author:
*    Lance Bunch
* Summary: 
*    This is the base-class that enables various schedule algorithms
*    to simulate CPU Scheduling
************************************************************************/

#ifndef SCHEDULER_SJF
#define SCHEDULER_SJF

#include "schedule.h"

/****************************************************
 * SJF
 * The Shortest Job First scheduler
 ***************************************************/
class SchedulerSJF : public Disbatcher
{
public:
   SchedulerSJF() : Disbatcher() {}

   // a new process has just been executed
   void startProcess(int pid)
   {
      waiting.push_back(pid);
   }

   // execute one clock cycle
   bool clock()
   {
      // is the current process finished or is there no process selected?
      if (pidCurrent == PID_NONE || processes[pidCurrent].isDone())
      {
            }

      return Disbatcher::clock();
   }

private:
   std::vector<int> waiting;
};

#endif // SCHEDULE_SJF
