/***********************************************************************
* Component:
*    Scheduler RR
* Author:
*    Lance Bunch
* Summary: 
*    This is the base-class that enables various schedule algorithms
*    to simulate CPU Scheduling
************************************************************************/

#ifndef SCHEDULER_RR
#define SCHEDULER_RR

#include "schedule.h"

using namespace std;

/****************************************************
 * RR
 * The Round Robin scheduler
 ***************************************************/
class SchedulerRR : public Disbatcher
{
public:
   SchedulerRR(int q) : Disbatcher(),
                        timeQuantaDuration(q) {}

   // a new process has just been executed
   void startProcess(int pid)
   {
   }

   // execute one clock cycle
   bool clock()
   {

      return Disbatcher::clock();
   }

private:
   int timeQuantaDuration;
};

#endif // SCHEDULE_RR
