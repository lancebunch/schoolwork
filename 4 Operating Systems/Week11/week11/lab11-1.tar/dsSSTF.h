/***********************************************************************
* Component:
*    DISK SCHEDULING SSTF
* Author:
*    <your name here>
* Summary: 
*    This is the DERRIVED class to implement the SSTF algorithm
************************************************************************/

#ifndef DS_SSTF
#define DS_SSTF

#include "ds.h"   // for the DiskSchedulingAlgorithm base-class
#include <limits.h>
#include <algorithm> // for the sort function.
#include <vector> // for the vector class.
#include <cassert> // for safety
#include "RequestObject.h" // for the RequestObject class.
 using namespace std;
 
/****************************************************
 * SSTF
 * The Sortest-Seek-Time-First disk scheduling algorithm
 ***************************************************/
class DiskSchedulingSSTF : public DiskSchedulingAlgorithm
{
public:
   /*****************************************************
    * CONSTRUCTOR
    * initialize the data structures specific to SSTF
    *****************************************************/
   DiskSchedulingSSTF(const ScheduleProblem & problem) :
             DiskSchedulingAlgorithm(problem)
   {
      // copy the problem requests.
      for (int request : problem.requests)
      {
         RequestObject requestObject;
         requestObject.num = request;
         requestObject.algorithm = this;
         requestObjects.push_back(requestObject);
      }
   }

   /****************************************************
    * RUN
    * Implement the algorithm here. This function will only
    * be called once and will need to complete the entire
    * simulation.
    *
    * Each time a disk request is made by setting currentLocation,
    * call record() to save that.
    ***************************************************/
   void run()
   {
      assert(currentLocation >= 0);
      // Iterate through each request,
      // shortest seek time first.
      while (requestObjects.size() > 0)
      {
         sort(requestObjects.begin(),requestObjects.end(),RequestObject::distanceComparator);
         auto iterator = requestObjects.begin();
         RequestObject requestObject = *iterator;
         currentLocation = requestObject.num;
         record();
         requestObjects.erase(iterator);
      }
      return;
   }

private:
   vector<RequestObject> requestObjects; // Store the requests that come in as "Request" objects.
};

#endif // DS_SSTF
