#include <iostream>
using namespace std;
int main()
{
   int i=0;
   for (i; i<10; ++i);
   cout << i;
}