/***********************************************************************
* Component:
*    DISK SCHEDULING LOOK
* Author:
*    <your name here>
* Summary: 
*    This is the DERRIVED class to implement the LOOK algorithm
************************************************************************/

#ifndef DS_LOOK
#define DS_LOOK

#include "ds.h"   // for the DiskSchedulingAlgorithm base-class
#include <cassert> // for safety.
// using namespace std;

/****************************************************
 * SCAN
 * The LOOK (SCAN with lookahead) disk scheduling algorithm
 ***************************************************/
class DiskSchedulingLOOK : public DiskSchedulingAlgorithm
{
public:
   /*****************************************************
    * CONSTRUCTOR
    * initialize the data structures specific to SCAN
    *****************************************************/
   DiskSchedulingLOOK(const ScheduleProblem & problem) :
             DiskSchedulingAlgorithm(problem)
   {
      // copy the problem requests.
      requests = problem.requests;
      increasing = problem.increasing;
      // Sort 'requests' in ascending order.
      requests.sort(DiskSchedulingLOOK::sortComparator);
      int a;
      for (int request : requests)
      {
         assert (request >= a);
         a = request;
      }
   }

   /****************************************************
    * RUN
    * Implement the algorithm here. This function will only
    * be called once and will need to complete the entire
    * simulation.
    *
    * Each time a disk request is made by setting currentLocation,
    * call record() to save that.
    ***************************************************/         
   void run()
   {
      // Starting at currentLocation,
      // go to the final request,
      // then reverse.
      for (int i=0; i<2; i++)
      {
         currentLocation = iterateCurrentLocation();
         increasing = !increasing;  
      }
      return;
   }

private:
   list<int> requests; // Store the requests that come in.
   bool increasing; // Indicates if disk head is increasing.
   
   /****************************************************
    * sortComparator
    * Used to sort 'requests' in ascending order.
   ***************************************************/
   static bool sortComparator(int a, int b)
   {
      return a < b;
   }
   /****************************************************
    * iterateCurrentLocation
    * Increments/decrements currentLocation, according to 'increasing',
    * until the final request in the given direction is reached.
   ***************************************************/
   int iterateCurrentLocation()
   {     
         int endLocation;
         if (increasing)
         {
            endLocation = requests.back();
            // Iterate through all possible locations in ascending order.
            for (currentLocation = currentLocation; currentLocation <= endLocation; currentLocation++)
            {
               // Try to find currentLocation in requests.
               auto iterator = find(requests.begin(),requests.end(),currentLocation);
               // If currentLocation is found in requests,
               if (iterator != requests.end())
               {
                  requests.erase(iterator);
                  // record our find.
                  record();
               }
            }
         }
         else
         {
            endLocation = requests.front();
            // Iterate through all possible locations in descending order.
            for (currentLocation = currentLocation; currentLocation >= endLocation; currentLocation--)
            {
               // Try to find currentLocation in requests.
               auto iterator = find(requests.begin(),requests.end(),currentLocation);
               if (iterator != requests.end())
               {
                  requests.erase(iterator);
                  // record our find.
                  record();
               }
            }
         }
         return endLocation;
   }
};

#endif // DS_LOOK
