/***********************************************************************
* Component:
*    DISK SCHEDULING C-LOOK
* Author:
*    <your name here>
* Summary: 
*    This is the DERRIVED class to implement the C-LOOK algorithm
************************************************************************/

#ifndef DS_C_LOOK
#define DS_C_LOOK

#include "ds.h"   // for the DiskSchedulingAlgorithm base-class

//using namespace std;

/****************************************************
 * C-LOOK
 * The C-LOOK disk scheduling algorithm
 ***************************************************/
class DiskSchedulingC_LOOK : public DiskSchedulingAlgorithm
{
public:
   /*****************************************************
    * CONSTRUCTOR
    * initialize the data structures specific to C-LOOK
    *****************************************************/
   DiskSchedulingC_LOOK(const ScheduleProblem & problem) :
     DiskSchedulingAlgorithm(problem)
   {
      // copy the problem requests.
      requests = problem.requests;
      increasing = problem.increasing;
      // Sort 'requests' in ascending order.
      requests.sort(DiskSchedulingC_LOOK::sortComparator);
      int a;
      for (int request : requests)
      {
         assert (request >= a);
         a = request;
      }
   }

   /****************************************************
    * RUN
    * Implement the algorithm here. This function will only
    * be called once and will need to complete the entire
    * simulation. With file location, send the results to record().
    ***************************************************/
   void run()
   {
      // Similar to LOOK,
      // but go back without fulfilling any requests.
      for (int i=0; i<2; i++)
      {
         // The for loops set currentLocation incorrectly.
         // The below line resets currentLocation to where it should be.
         currentLocation = iterateCurrentLocation();
         if (increasing)
            currentLocation = requests.front();
         else
            currentLocation = requests.back();
      }
      return;
   }

private:
   list<int> requests; // Store the requests that come in.
   bool increasing; // Indicates if disk head is increasing.
   
   /****************************************************
    * sortComparator
    * Used to sort 'requests' in ascending order.
   ***************************************************/
   static bool sortComparator(int a, int b)
   {
      return a < b;
   }
   /****************************************************
    * iterateCurrentLocation
    * Increments/decrements currentLocation, according to 'increasing',
    * until the final request in the given direction is reached.
   ***************************************************/
   int iterateCurrentLocation()
   {     
         int endLocation;
         if (increasing)
         {
            endLocation = requests.back();
            // Iterate through all possible locations in ascending order.
            for (currentLocation = currentLocation; currentLocation <= endLocation; currentLocation++)
            {
               // Try to find currentLocation in requests.
               auto iterator = find(requests.begin(),requests.end(),currentLocation);
               // If currentLocation is found in requests,
               if (iterator != requests.end())
               {
                  requests.erase(iterator);
                  // record our find.
                  record();
               }
            }
         }
         else
         {
            endLocation = requests.front();
            // Iterate through all possible locations in descending order.
            for (currentLocation = currentLocation; currentLocation >= endLocation; currentLocation--)
            {
               // Try to find currentLocation in requests.
               auto iterator = find(requests.begin(),requests.end(),currentLocation);
               if (iterator != requests.end())
               {
                  requests.erase(iterator);
                  // record our find.
                  record();
               }
            }
         }
         return endLocation;
   }
};

#endif // DS_C_LOOK
