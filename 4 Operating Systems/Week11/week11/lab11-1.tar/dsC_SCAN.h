/***********************************************************************
* Component:
*    DISK SCHEDULING C-SCAN
* Author:
*    <your name here>
* Summary: 
*    This is the DERRIVED class to implement the C-SCAN algorithm
************************************************************************/

#ifndef DS_C_SCAN
#define DS_C_SCAN

#include "ds.h"   // for the DiskSchedulingAlgorithm base-class
#include <cassert>
//using namespace std;

/****************************************************
 * C-SCAN
 * The C-SCAN disk scheduling algorithm
 ***************************************************/
class DiskSchedulingC_SCAN : public DiskSchedulingAlgorithm
{
public:
   /*****************************************************
    * CONSTRUCTOR
    * initialize the data structures specific to C-SCAN
    *****************************************************/
   DiskSchedulingC_SCAN(const ScheduleProblem & problem) :
     DiskSchedulingAlgorithm(problem)
   {
      // copy the problem requests.
      requests = problem.requests;
      increasing = problem.increasing;
      diskSize = problem.diskSize;
   }

   /****************************************************
    * RUN
    * Implement the algorithm here. This function will only
    * be called once and will need to complete the entire
    * simulation. With file location, send the results to record().
    ***************************************************/
   void run()
   {
      // Do the same thing as SCAN,
      // except after reaching one end of the disk,
      // go directly to the beginning,
      // without fulfilling any requests,
      // then begin SCAN again.
      for (int i=0; i<2; i++)
      {
         int startingLocation = currentLocation;
         // The for loops set currentLocation incorrectly.
         // This resets currentLocation to where it should be.
         currentLocation = iterateCurrentLocation();
         assert((currentLocation > startingLocation) == increasing);
         if (i == 0)
         {
            record();
            if (increasing)
               currentLocation = 0;
            else
               currentLocation = diskSize - 1;
            record();
         }
      }
      return;
   }

private:
   list<int> requests;
   unsigned int diskSize;
   bool increasing;
     /****************************************************
    * iterateCurrentLocation
    * Increments/decrements currentLocation, according to 'increasing'
   ***************************************************/
   int iterateCurrentLocation()
   {
         int endLocation; // The ending location of the disk head.
         if (increasing)
         {
            endLocation = diskSize - 1;
            // Iterate through all possible locations in ascending order.
            for (currentLocation = currentLocation; currentLocation <= endLocation; currentLocation++)
            {
               // Try to find currentLocation in requests.
               auto iterator = find(requests.begin(),requests.end(),currentLocation);
               // If currentLocation is found in requests,
               if (iterator != requests.end())
               {
                  requests.erase(iterator);
                  // record our find.
                  record();
               }
            }
         }
         else
         {
            endLocation = 0;
            // Iterate through all possible locations in descending order.
            for (currentLocation = currentLocation; currentLocation >= endLocation; currentLocation--)
            {
               // Try to find currentLocation in requests.
               auto iterator = find(requests.begin(),requests.end(),currentLocation);
               if (iterator != requests.end())
               {
                  requests.erase(iterator);
                  // record our find.
                  record();
               }
            }
         }
         return endLocation;
   }
};

#endif // DS_C_SCAN
