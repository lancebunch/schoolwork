/***********************************************************************
* Component:
*    REQUEST_OBJECT
* Author:
*    Montana Burr
* Summary: 
*    This is a class that represents requests.
************************************************************************/

/****************************************************
 * REQUEST_OBJECT
 * Represents a request.
 ***************************************************/
 struct RequestObject
 {
   int num; // The number associated with the request.
   DiskSchedulingAlgorithm *algorithm; // The algorithm instance associated with this request.
   /****************************************************
   * DISTANCE_TO_CURRENT_LOCATION
   * Returns the distance to the disk head.
   ***************************************************/
   int distanceToCurrentLocation()
   {
      return algorithm->computeDistance(num);
   }
    /****************************************************
   * DISTANCE_COMPARATOR
   * Used to sort requests by distance to the disk head,
   * in ascending order.
   ***************************************************/
   static bool distanceComparator(RequestObject a,RequestObject b)
   {
      return a.distanceToCurrentLocation() < b.distanceToCurrentLocation();
   }
   /****************************************************
   * ASCENDING_COMPARATOR
   * Used to sort request numbers in ascending order.
   ***************************************************/
   static bool ascendingComparator(RequestObject a, RequestObject b)
   {
      return a.num < b.num;
   };
    /****************************************************
   * DESCENDING_COMPARATOR
   * Used to sort request numbers in descending order.
   ***************************************************/
   static bool descendingComparator(RequestObject a, RequestObject b)
   {
      return a.num > b.num;
   };
 };