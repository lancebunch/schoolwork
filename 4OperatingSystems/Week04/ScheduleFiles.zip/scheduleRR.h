/***********************************************************************
* Component:
*    Scheduler RR
* Author:
*    Lance Bunch
* Summary: 
*    This is the base-class that enables various schedule algorithms
*    to simulate CPU Scheduling
************************************************************************/

#ifndef SCHEDULER_RR
#define SCHEDULER_RR

#include "schedule.h"

using namespace std;

/****************************************************
 * RR
 * The Round Robin scheduler
 ***************************************************/
class SchedulerRR : public Disbatcher
{
public:
   SchedulerRR(int q) : Disbatcher(),
                        timeQuantaDuration(q), timeQuantaRemaining(q) {}

   // a new process has just been executed
   void startProcess(int pid)
   {
      readyQueue.push(pid);
   }

   // execute one clock cycle
   bool clock()
   {
      if (processes[pidCurrent].isDone())
      {
         if (readyQueue.size())
         {
            pidCurrent = readyQueue.front();
            readyQueue.pop();
            timeQuantaRemaining = timeQuantaDuration;
         }
         else
            pidCurrent = PID_NONE;
      }
      else if (!timeQuantaRemaining)
      {
         readyQueue.push(pidCurrent);
         pidCurrent = readyQueue.front();
         readyQueue.pop();
         timeQuantaRemaining = timeQuantaDuration;
      }
      else if (pidCurrent == PID_NONE)
      {
         if (readyQueue.size())
         {
            pidCurrent = readyQueue.front();
            readyQueue.pop();
            timeQuantaRemaining = timeQuantaDuration;
         }
      }
      else
      {
         timeQuantaRemaining--;
      }

      return Disbatcher::clock();
   }

private:
   int timeQuantaDuration;
   int timeQuantaRemaining;
   queue<int> readyQueue;
};

#endif // SCHEDULE_RR
