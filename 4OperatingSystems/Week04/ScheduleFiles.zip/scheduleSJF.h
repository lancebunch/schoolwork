/***********************************************************************
* Component:
*    Scheduler SJF
* Author:
*    Lance Bunch
* Summary: 
*    This is the base-class that enables various schedule algorithms
*    to simulate CPU Scheduling
************************************************************************/

#ifndef SCHEDULER_SJF
#define SCHEDULER_SJF

#include "schedule.h"

/****************************************************
 * SJF
 * The Shortest Job First scheduler
 ***************************************************/
class SchedulerSJF : public Disbatcher
{
   SchedulerSRT() : Disbatcher() {}

   // a new process has just been executed
   void startProcess(int pid)
   {
      myQueue.push(pid);
   }

   // execute one clock cycle
   bool clock()
   {
      if (pidCurrent == PID_NONE || processes[pidCurrent].isDone())
      {
         // execute if the myQueue in not NULL
         if (myQueue.size())
         {
            std::queue<int> iterate;

            // make copy of queue
            int smallestSize = 100; // set to large number for service time
            for (int i = 0; i < myQueue.size(); i++)
            {
               iterate.push(i);
            }
            for (auto it = iterate.front(); it != iterate.back(); it++)
            {
               if (smallestSize > it)
               {
                  myQueue.front() = it;
               }
            }
         }
         // call the base-class which will handle a variety of housekeeping chores
         return Disbatcher::clock();
      }
   }

private:
   std::queue<int> myQueue;
};

#endif // SCHEDULE_SJF
